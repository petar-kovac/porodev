﻿Console.WriteLine($"Current date is: {DateTime.Now}");
